package com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer;

import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;

/**
 * Created by C0229411 on 05/06/2017.
 **/

public interface MakeInternalTransferGassMQServiceInterface {
    void sendToMQMakeInternalTransfer(MakeInternalTransferGassItem makeInternalTransferGassItem) throws Exception;
}
