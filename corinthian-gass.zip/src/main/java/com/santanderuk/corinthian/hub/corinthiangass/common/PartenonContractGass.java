package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.Marshaller;

public class PartenonContractGass {


    private String company;
    private String centre;
    private String product;
    private String contract;

    public PartenonContractGass() {
    }

    public PartenonContractGass(String company, String centre, String product, String contract) {
        this.company = company;
        this.centre = centre;
        this.product = product;
        this.contract = contract;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCentre() {
        return centre;
    }

    public void setCentre(String centre) {
        this.centre = centre;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    private void beforeMarshal(Marshaller marshaller) {
        if (null == company) {
            company = "";
        }

        if (null == centre) {
            centre = "";
        }

        if (null == product) {
            product = "";
        }
        if (null == contract) {
            contract = "";
        }

    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("company", company)
                .append("centre", centre)
                .append("product", product)
                .append("contract", contract)
                .toString();
    }
}
