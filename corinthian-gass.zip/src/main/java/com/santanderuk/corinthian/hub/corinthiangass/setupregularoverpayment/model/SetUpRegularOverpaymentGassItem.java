package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model;


import com.santanderuk.corinthian.hub.corinthiangass.common.GassCategorization;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassDefaultValueFields;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassMqDetails;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by C0229411 on 01/06/2017.
 **/

@Getter
@Setter
public class SetUpRegularOverpaymentGassItem {

    private GassMqDetails gassMqDetails;
    private GassDefaultValueFields gassDefaultValueFields;
    private GassCategorization gassCategorization;
    private SetUpRegularOverpaymentGassMessage gassMessage;
    private String stringAuditRecord;


    public SetUpRegularOverpaymentGassItem() {
        super();
    }

    public SetUpRegularOverpaymentGassItem(String gassMqHost, String gassMqVirtualHost, int gassMqPort, String gassMqQueue, String gassMqUsername, String gassMqPassword, String compsysid,
                                           String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid, String appsysid, String audittrngrpid, String trntpname,
                                           String oprtnsuctyp, String custNumber, String account, String amount, String clientIPAddress, String userID, SetUpRegularOverpaymentFormattedData formattedData) {
        super();
        this.gassMqDetails = new GassMqDetails(gassMqHost, gassMqVirtualHost, gassMqPort, gassMqQueue, gassMqUsername, gassMqPassword);
        this.gassDefaultValueFields = new GassDefaultValueFields(compsysid, dvctyp, orgid, orguttp, authcduserid, authcdcompsysid);
        this.gassCategorization = new GassCategorization(appsysid, audittrngrpid, trntpname);
        this.gassMessage = new SetUpRegularOverpaymentGassMessage(oprtnsuctyp, clientIPAddress, userID, custNumber, account, amount, formattedData);
    }

    public SetUpRegularOverpaymentGassItem(GassMqDetails gassMqDetails, GassDefaultValueFields gassDefaultValueFields, GassCategorization gassCategorization,
                                           SetUpRegularOverpaymentGassMessage gassMessage) {
        this.gassMqDetails = gassMqDetails;
        this.gassDefaultValueFields = gassDefaultValueFields;
        this.gassCategorization = gassCategorization;
        this.gassMessage = gassMessage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("gassMqDetails", gassMqDetails)
                .append("gassDefaultValueFields", gassDefaultValueFields)
                .append("gassCategorization", gassCategorization)
                .append("gassMessage", gassMessage)
                .append("stringAuditRecord", stringAuditRecord)
                .toString();
    }
}
