package com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model;


import com.santanderuk.corinthian.hub.corinthiangass.common.GassCategorization;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassDefaultValueFields;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassMqDetails;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by C0229411 on 01/06/2017.
 **/


public class MakeInternalTransferGassItem {

    private GassMqDetails gassMqDetails;
    private GassDefaultValueFields gassDefaultValueFields;
    private GassCategorization gassCategorization;
    private MakeInternalTransferGassMessage gassMessage;
    private String stringAuditRecord;


    public MakeInternalTransferGassItem() {
        super();
    }

    public MakeInternalTransferGassItem(String gassMqHost, String gassMqVirtualHost, int gassMqPort, String gassMqQueue, String gassMqUsername, String gassMqPassword, String compsysid,
                                        String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid, String appsysid, String audittrngrpid, String trntpname,
                                        String oprtnsuctyp, String custNumber, String account, String amount, String clientIPAddress, String userID, MakeInternalTransferFormattedData formattedData) {
        super();
        this.gassMqDetails = new GassMqDetails(gassMqHost, gassMqVirtualHost, gassMqPort, gassMqQueue, gassMqUsername, gassMqPassword);
        this.gassDefaultValueFields = new GassDefaultValueFields(compsysid, dvctyp, orgid, orguttp, authcduserid, authcdcompsysid);
        this.gassCategorization = new GassCategorization(appsysid, audittrngrpid, trntpname);
        this.gassMessage = new MakeInternalTransferGassMessage(oprtnsuctyp, clientIPAddress, userID, custNumber, account, amount, formattedData);
    }

    public MakeInternalTransferGassItem(GassMqDetails gassMqDetails, GassDefaultValueFields gassDefaultValueFields, GassCategorization gassCategorization,
                                        MakeInternalTransferGassMessage gassMessage) {
        this.gassMqDetails = gassMqDetails;
        this.gassDefaultValueFields = gassDefaultValueFields;
        this.gassCategorization = gassCategorization;
        this.gassMessage = gassMessage;
    }

    public GassMqDetails getGassMqDetails() {
        return gassMqDetails;
    }

    public void setGassMqDetails(GassMqDetails gassMqDetails) {
        this.gassMqDetails = gassMqDetails;
    }

    public GassDefaultValueFields getGassDefaultValueFields() {
        return gassDefaultValueFields;
    }

    public void setGassDefaultValueFields(GassDefaultValueFields gassDefaultValueFields) {
        this.gassDefaultValueFields = gassDefaultValueFields;
    }

    public GassCategorization getGassCategorization() {
        return gassCategorization;
    }

    public void setGassCategorization(GassCategorization gassCategorization) {
        this.gassCategorization = gassCategorization;
    }

    public MakeInternalTransferGassMessage getGassMessage() {
        return gassMessage;
    }

    public void setGassMessage(MakeInternalTransferGassMessage gassMessage) {
        this.gassMessage = gassMessage;
    }

    public String getStringAuditRecord() {
        return stringAuditRecord;
    }

    public void setStringAuditRecord(String stringAuditRecord) {
        this.stringAuditRecord = stringAuditRecord;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("gassMqDetails", gassMqDetails.toString())
                .append("gassDefaultValueFields", gassDefaultValueFields.toString())
                .append("gassCategorization", gassCategorization.toString())
                .append("gassMessage", gassMessage.toString())
                .append("stringAuditRecord", stringAuditRecord)
                .toString();
    }
}
