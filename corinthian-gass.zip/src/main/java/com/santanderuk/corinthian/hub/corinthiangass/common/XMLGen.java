package com.santanderuk.corinthian.hub.corinthiangass.common;


import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
public class XMLGen {

    private static final String XMLVERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

    private static final String AUDITRECORDS = "<AuditRecords>";

    private static final String AUDITRECORD = "<AuditRecord>";

    private static final String AUDITRECORDTRN = "<AuditRecordTrn>";

    private static final String AUDITTRNGRPID = "<AUDITTRNGRPID>";

    private static final String AUDITTRNGRPIDT = "</AUDITTRNGRPID>";
    private static final String AUDITTRNTPNAME = "<AUDITTRNTPNAME>";
    private static final String AUDITTRNTPNAMET = "</AUDITTRNTPNAME>";
    private static final String AUDITRECORDTRNT = "</AuditRecordTrn>";
    private static final String AUDITRECORDWHO = "<AuditRecordWho>";
    private static final String AUDITRECAUTHCDUSER = "<AUDITRECAUTHCDUSER>";
    private static final String USRID = "<USRID>";
    private static final String USRIDT = "</USRID>";
    private static final String COMPSYSID = "<COMPSYSID>";
    private static final String COMPSYSIDT = "</COMPSYSID>";
    private static final String AUDITRECAUTHCDUSERT = "</AUDITRECAUTHCDUSER>";
    private static final String AUDITRECINSTGRUSER = "<AUDITRECINSTGRUSER>";
    private static final String AUDITRECINSTGRUSERT = "</AUDITRECINSTGRUSER>";
    private static final String AUDITRECORDWHOT = "</AuditRecordWho>";
    private static final String AUDITRECORDLOGKEY = "<AuditRecordLogKey>";
    private static final String AUDDTTM = "<AUDDTTM>";
    private static final String AUDDTTMT = "</AUDDTTM>";
    private static final String OPRTNSUCTYP = "<OPRTNSUCTYP>";
    private static final String OPRTNSUCTYPT = "</OPRTNSUCTYP>";
    private static final String TRNCLTREF = "<TRNCLTREF>";
    private static final String TRNCLTREFT = "</TRNCLTREF>";
    private static final String KEYALTUID = "<KEYALTUID>";
    private static final String KEYALTUIDT = "</KEYALTUID>";
    private static final String KEYUSERID = "<KEYUSERID>";
    private static final String KEYUSERIDT = "</KEYUSERID>";
    private static final String KEYHLDGREF = "<KEYHLDGREF>";
    private static final String KEYHLDGREFT = "</KEYHLDGREF>";
    private static final String KEYAMT = "<KEYAMT>";
    private static final String KEYAMTT = "</KEYAMT>";
    private static final String AUDITRECORDLOGKEYT = "</AuditRecordLogKey>";
    private static final String AUDITRECORDWHERE = "<AuditRecordWhere>";
    private static final String DVCTYP = "<DVCTYP>";
    private static final String DVCTYPT = "</DVCTYP>";
    private static final String DVCID = "<DVCID>";
    private static final String DVCIDT = "</DVCID>";
    private static final String APPSYSID = "<APPSYSID>";
    private static final String APPSYSIDT = "</APPSYSID>";
    private static final String ORGID = "<ORGID>";
    private static final String ORGIDT = "</ORGID>";
    private static final String ORGUTTP = "<ORGUTTP>";
    private static final String ORGUTTPT = "</ORGUTTP>";
    private static final String AUDITRECORDWHERET = "</AuditRecordWhere>";
    private static final String AUDITRECORDWHAT = "<AuditRecordWhat>";
    private static final String FRMTDDATA = "<FRMTDDATA esc=\"Y\"><![CDATA[";
    private static final String FRMTDDATAT = "]]></FRMTDDATA>";
    private static final String AUDITRECORDWHATT = "</AuditRecordWhat>";
    private static final String AUDITRECORDT = "</AuditRecord>";
    private static final String AUDITRECORDST = "</AuditRecords>";

    private String createAuditOfAuditXML(AuditRecord auditRecord) {
        StringBuilder generatedXml = new StringBuilder();

        generatedXml.append(XMLVERSION);

        generatedXml.append(AUDITRECORDS);

        generatedXml.append(AUDITRECORD);

        generatedXml.append(AUDITRECORDTRN);

        generatedXml.append(AUDITTRNGRPID);
        generatedXml.append(auditRecord.getAudittrngrpid());
        generatedXml.append(AUDITTRNGRPIDT);

        generatedXml.append(AUDITTRNTPNAME);
        generatedXml.append(auditRecord.getAudittrntpname());
        generatedXml.append(AUDITTRNTPNAMET);

        generatedXml.append(AUDITRECORDTRNT);

        generatedXml.append(AUDITRECORDWHO);

        generatedXml.append(AUDITRECINSTGRUSER);

        generatedXml.append(USRID);
        generatedXml.append(auditRecord.getUserID());
        generatedXml.append(USRIDT);

        generatedXml.append(COMPSYSID);
        generatedXml.append(auditRecord.getCompsysid());
        generatedXml.append(COMPSYSIDT);

        generatedXml.append(AUDITRECINSTGRUSERT);

        // Only include this section if both authcduserid and authcdcompsysid are specified
        if (auditRecord.getAuthcduserid() != null && auditRecord.getAuthcdcompsysid() != null) {
            generatedXml.append(AUDITRECAUTHCDUSER);

            generatedXml.append(USRID);
            generatedXml.append(auditRecord.getAuthcduserid());
            generatedXml.append(USRIDT);

            generatedXml.append(COMPSYSID);
            generatedXml.append(auditRecord.getAuthcdcompsysid());
            generatedXml.append(COMPSYSIDT);

            generatedXml.append(AUDITRECAUTHCDUSERT);
        }

        generatedXml.append(AUDITRECORDWHOT);

        generatedXml.append(AUDITRECORDLOGKEY);

        generatedXml.append(AUDDTTM);
        Date currDate = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String formattedCurrDate = simpleDateFormat.format(currDate);
        generatedXml.append(formattedCurrDate);
        generatedXml.append(AUDDTTMT);

        generatedXml.append(OPRTNSUCTYP);
        generatedXml.append(auditRecord.getOprtnsuctyp());
        generatedXml.append(OPRTNSUCTYPT);

        // This used to take a default value:
        // java.util.UUID.randomUUID().toString().subSequence(0, 25)
        // But is now configurable to take the value supplied by the application when the
        // auditRecord is created or to be excluded from the output if no value is supplied
        if (auditRecord.getTrncltref() != null) {
            generatedXml.append(TRNCLTREF);
            generatedXml.append(auditRecord.getTrncltref());
            generatedXml.append(TRNCLTREFT);
        }

        if (auditRecord.getKeyAltUID() != null) {
            generatedXml.append(KEYALTUID);
            generatedXml.append(auditRecord.getKeyAltUID());
            generatedXml.append(KEYALTUIDT);
        }

        if (auditRecord.getKeyUserID() != null) {
            generatedXml.append(KEYUSERID);
            generatedXml.append(auditRecord.getKeyUserID());
            generatedXml.append(KEYUSERIDT);
        }

        if (auditRecord.getKeyhldgref() != null) {
            generatedXml.append(KEYHLDGREF);
            generatedXml.append(auditRecord.getKeyhldgref());
            generatedXml.append(KEYHLDGREFT);
        }

        if (auditRecord.getKeyamt() != null) {
            generatedXml.append(KEYAMT);
            generatedXml.append(auditRecord.getKeyamt());
            generatedXml.append(KEYAMTT);
        }

        generatedXml.append(AUDITRECORDLOGKEYT);

        generatedXml.append(AUDITRECORDWHERE);

        generatedXml.append(DVCTYP);
        generatedXml.append(auditRecord.getDvctyp());
        generatedXml.append(DVCTYPT);

        generatedXml.append(DVCID);
        generatedXml.append(auditRecord.getDvcid());
        generatedXml.append(DVCIDT);

        generatedXml.append(APPSYSID);
        generatedXml.append(auditRecord.getAppsysid());
        generatedXml.append(APPSYSIDT);

        generatedXml.append(ORGID);
        generatedXml.append(auditRecord.getOrgid());
        generatedXml.append(ORGIDT);

        generatedXml.append(ORGUTTP);
        generatedXml.append(auditRecord.getOrguttp());
        generatedXml.append(ORGUTTPT);

        generatedXml.append(AUDITRECORDWHERET);

        generatedXml.append(AUDITRECORDWHAT);

        generatedXml.append(FRMTDDATA);
        generatedXml.append(auditRecord.getFormattedData());
        generatedXml.append(FRMTDDATAT);
        generatedXml.append(AUDITRECORDWHATT);

        generatedXml.append(AUDITRECORDT);
        generatedXml.append(AUDITRECORDST);

        return generatedXml.toString();
    }

    public String retrieveXML(AuditRecord auditRecord) {
        log.debug("Start the generation");
        return createAuditOfAuditXML(auditRecord);
    }

    public String prettyFormat(String xml) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db
                    .parse(new InputSource(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))));

            XPath xPath = XPathFactory.newInstance().newXPath();
            NodeList nodeList = (NodeList) xPath.evaluate("//text()[normalize-space()='']", document,
                    XPathConstants.NODESET);

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                node.getParentNode().removeChild(node);
            }

            TransformerFactory transformerFactory = javax.xml.transform.TransformerFactory.newInstance();
            transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

            Transformer transformer = transformerFactory.newTransformer();

            transformer.setOutputProperty("encoding", "UTF-8");

            transformer.setOutputProperty("indent", "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

            StringWriter stringWriter = new StringWriter();
            StreamResult streamResult = new StreamResult(stringWriter);

            transformer.transform(new DOMSource(document), streamResult);

            return stringWriter.toString();

        } catch (Exception e) {
            log.error("pretty format error", e);
        }
        return xml;
    }
}
