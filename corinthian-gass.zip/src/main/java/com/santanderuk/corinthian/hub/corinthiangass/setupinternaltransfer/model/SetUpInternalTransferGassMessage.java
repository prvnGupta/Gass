package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by C0229411 on 07/06/2017.
 **/

public class SetUpInternalTransferGassMessage {

    private String oprtnsuctyp;
    private String clientIPAddress;
    private String userID;
    private String custNumber;
    private String account;
    private String amount;
    private SetUpInternalTransferFormattedData formattedData;

    public SetUpInternalTransferGassMessage(String oprtnsuctyp, String clientIPAddress, String userID, String custNumber, String account, String amount, SetUpInternalTransferFormattedData formattedData) {
        this.oprtnsuctyp = oprtnsuctyp;
        this.clientIPAddress = clientIPAddress;
        this.userID = userID;
        this.custNumber = custNumber;
        this.account = account;
        this.amount = amount;
        this.formattedData = formattedData;
    }

    public String getOprtnsuctyp() {
        return oprtnsuctyp;
    }

    public void setOprtnsuctyp(String oprtnsuctyp) {
        this.oprtnsuctyp = oprtnsuctyp;
    }

    public String getClientIPAddress() {
        return clientIPAddress;
    }

    public void setClientIPAddress(String clientIPAddress) {
        this.clientIPAddress = clientIPAddress;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getCustNumber() {
        return custNumber;
    }

    public void setCustNumber(String custNumber) {
        this.custNumber = custNumber;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public SetUpInternalTransferFormattedData getFormattedData() {
        return formattedData;
    }

    public void setFormattedData(SetUpInternalTransferFormattedData formattedData) {
        this.formattedData = formattedData;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("oprtnsuctyp", oprtnsuctyp)
                .append("clientIPAddress", clientIPAddress)
                .append("userID", userID)
                .append("custNumber", custNumber)
                .append("account", account)
                .append("amount", amount)
                .append("formattedData", formattedData)
                .toString();
    }
}
