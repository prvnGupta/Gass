package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class GassCategorization {
    private String appsysid;
    private String audittrngrpid;
    private String trntpname;

    public GassCategorization(String appsysid, String audittrngrpid, String trntpname) {
        this.appsysid = appsysid;
        this.audittrngrpid = audittrngrpid;
        this.trntpname = trntpname;
    }

    public String getAppsysid() {
        return appsysid;
    }

    public void setAppsysid(String appsysid) {
        this.appsysid = appsysid;
    }

    public String getAudittrngrpid() {
        return audittrngrpid;
    }

    public void setAudittrngrpid(String audittrngrpid) {
        this.audittrngrpid = audittrngrpid;
    }

    public String getTrntpname() {
        return trntpname;
    }

    public void setTrntpname(String trntpname) {
        this.trntpname = trntpname;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("appsysid", appsysid)
                .append("audittrngrpid", audittrngrpid)
                .append("trntpname", trntpname)
                .toString();
    }
}
