package com.santanderuk.corinthian.hub.corinthiangass.processor;

import com.santanderuk.corinthian.hub.corinthiangass.common.AuditRecord;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentFormattedData;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Slf4j
public class GassMessageProcessor {
    private static final String ENCUTF8 = StandardCharsets.UTF_8.name();

    public String setUpInternalTransferFormattedDataToXmlString(SetUpInternalTransferFormattedData formattedData) throws Exception {

        String xmlString;
        String sreturn;

        try {
            JAXBContext jc = JAXBContext.newInstance(SetUpInternalTransferFormattedData.class);
            Marshaller marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            marshaller.marshal(formattedData, sw);
            xmlString = sw.toString();

            sreturn = URLEncoder.encode(xmlString, ENCUTF8);
            sreturn = sreturn.replace('+', ' ');
        } catch (Exception e) {
            log.error("GassMessageProcessor - Setup Internal Payment - > Error while formatting formatted data field: ", e);
            throw e;
        }
        return sreturn;
    }


    public AuditRecord getSetUpInternalTransferAuditRecord(String appsysid, String trngrpid, String trntpname, String oprtnsuctyp, String clientIPAddress,
                                                           String userID, String custNumber, String account, String amount, SetUpInternalTransferFormattedData setUpInternalPaymentFormattedData, String compsysid,
                                                           String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid) throws Exception {
        AuditRecord auditRecord = new AuditRecord();

        try {
            log.info("GassMessageProcessor - Setup Internal Payment - > Assigning values to Audit record item");
            auditRecord.setAppsysid(appsysid);
            auditRecord.setAudittrngrpid(trngrpid);
            auditRecord.setAudittrntpname(trntpname);
            auditRecord.setOprtnsuctyp(oprtnsuctyp);
            auditRecord.setUserID(custNumber);
            auditRecord.setDvcid(clientIPAddress);
            auditRecord.setKeyAltUID(userID);
            auditRecord.setKeyhldgref(account);
            auditRecord.setTrncltref(account);
            auditRecord.setKeyamt(amountInCents(amount));
            auditRecord.setCompsysid(compsysid);
            auditRecord.setDvctyp(dvctyp);
            auditRecord.setOrgid(orgid);
            auditRecord.setOrguttp(orguttp);
            auditRecord.setAuthcduserid(authcduserid);
            auditRecord.setAuthcdcompsysid(authcdcompsysid);

            log.info("GassMessageProcessor - Setup Internal Payment - > Formatting Formatted Data");
            String formattedData = setUpInternalTransferFormattedDataToXmlString(setUpInternalPaymentFormattedData);
            auditRecord.setFormattedData(formattedData);
            log.info("GassMessageProcessor - Setup Internal Payment - > Formatted Data formatted correctly");
        } catch (Exception ex) {
            log.error("GassMessageProcessor - Setup Internal Payment - > Error while creating audit record: ", ex);
            throw ex;
        }

        return auditRecord;
    }

    public AuditRecord getSetUpRegularOverpaymentAuditRecord(String appsysid, String trngrpid, String trntpname, String oprtnsuctyp, String clientIPAddress,
                                                             String userID, String custNumber, String account, String amount, SetUpRegularOverpaymentFormattedData setUpRegularOverpaymentFormattedData, String compsysid,
                                                             String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid) throws Exception {
        AuditRecord auditRecord = new AuditRecord();

        try {
            log.info("GassMessageProcessor - Setup Internal Payment - > Assigning values to Audit record item");
            auditRecord.setAppsysid(appsysid);
            auditRecord.setAudittrngrpid(trngrpid);
            auditRecord.setAudittrntpname(trntpname);
            auditRecord.setOprtnsuctyp(oprtnsuctyp);
            auditRecord.setUserID(custNumber);
            auditRecord.setDvcid(clientIPAddress);
            auditRecord.setKeyAltUID(userID);
            auditRecord.setKeyhldgref(account);
            auditRecord.setTrncltref(account);
            auditRecord.setKeyamt(amountInCents(amount));
            auditRecord.setCompsysid(compsysid);
            auditRecord.setDvctyp(dvctyp);
            auditRecord.setOrgid(orgid);
            auditRecord.setOrguttp(orguttp);
            auditRecord.setAuthcduserid(authcduserid);
            auditRecord.setAuthcdcompsysid(authcdcompsysid);

            log.info("GassMessageProcessor - Setup Internal Payment - > Formatting Formatted Data");
            String formattedData = setUpRegularOverpaymentFormattedDataToXmlString(setUpRegularOverpaymentFormattedData);
            auditRecord.setFormattedData(formattedData);
            log.info("GassMessageProcessor - Setup Internal Payment - > Formatted Data formatted correctly");
        } catch (Exception ex) {
            log.error("GassMessageProcessor - Setup Internal Payment - > Error while creating audit record: ", ex);
            throw ex;
        }

        return auditRecord;
    }

    private String setUpRegularOverpaymentFormattedDataToXmlString(SetUpRegularOverpaymentFormattedData setUpRegularOverpaymentFormattedData) throws Exception {

        String xmlString;
        String sreturn;

        try {
            JAXBContext jc = JAXBContext.newInstance(SetUpRegularOverpaymentFormattedData.class);
            Marshaller marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            marshaller.marshal(setUpRegularOverpaymentFormattedData, sw);
            xmlString = sw.toString();

            sreturn = URLEncoder.encode(xmlString, ENCUTF8);
            sreturn = sreturn.replace('+', ' ');
        } catch (Exception e) {
            log.error("GassMessageProcessor - Setup Internal Payment - > Error while formatting formatted data field: ", e);
            throw e;
        }
        return sreturn;
    }

    public String makeInternalTransferFormattedDataToXmlString(MakeInternalTransferFormattedData formattedData) throws Exception {

        String xmlString;
        String sreturn;

        try {
            JAXBContext jc = JAXBContext.newInstance(MakeInternalTransferFormattedData.class);
            Marshaller marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            marshaller.marshal(formattedData, sw);
            xmlString = sw.toString();

            sreturn = URLEncoder.encode(xmlString, ENCUTF8);
            sreturn = sreturn.replace('+', ' ');
        } catch (Exception e) {
            log.error("GassMessageProcessor - Make Internal Payment - > Error while formatting formatted data field: ", e);
            throw e;
        }
        return sreturn;
    }


    public AuditRecord getMakeInternalTransferAuditRecord(String appsysid, String trngrpid, String trntpname, String oprtnsuctyp, String clientIPAddress,
                                                          String userID, String custNumber, String account, String amount, MakeInternalTransferFormattedData makeInternalPaymentFormattedData, String compsysid,
                                                          String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid) throws Exception {
        AuditRecord auditRecord = new AuditRecord();

        try {
            log.info("GassMessageProcessor - Make Internal Payment - > Assigning values to Audit record item");
            auditRecord.setAppsysid(appsysid);
            auditRecord.setAudittrngrpid(trngrpid);
            auditRecord.setAudittrntpname(trntpname);
            auditRecord.setOprtnsuctyp(oprtnsuctyp);
            auditRecord.setUserID(custNumber);
            auditRecord.setDvcid(clientIPAddress);
            auditRecord.setKeyAltUID(userID);
            auditRecord.setKeyhldgref(account);
            auditRecord.setTrncltref(account);
            auditRecord.setKeyamt(amountInCents(amount));
            auditRecord.setCompsysid(compsysid);
            auditRecord.setDvctyp(dvctyp);
            auditRecord.setOrgid(orgid);
            auditRecord.setOrguttp(orguttp);
            auditRecord.setAuthcduserid(authcduserid);
            auditRecord.setAuthcdcompsysid(authcdcompsysid);

            log.info("GassMessageProcessor - Make Internal Payment - > Formatting Formatted Data");
            String formattedData = makeInternalTransferFormattedDataToXmlString(makeInternalPaymentFormattedData);
            auditRecord.setFormattedData(formattedData);
            log.info("GassMessageProcessor - Make Internal Payment - > Formatted Data formatted correctly");
        } catch (Exception ex) {
            log.error("GassMessageProcessor - Make Internal Payment - > Error while creating audit record: ", ex);
            throw ex;
        }

        return auditRecord;
    }

    private String amountInCents(String amount) {
        BigDecimal a = new BigDecimal(amount);
        BigDecimal bgHundred = new BigDecimal("100");
        return String.valueOf(a.multiply(bgHundred).intValue());
    }
}
