package com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.implementation;

import com.santanderuk.corinthian.hub.corinthiangass.common.AuditRecord;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassAuditValidator;
import com.santanderuk.corinthian.hub.corinthiangass.common.XMLGen;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.MakeInternalTransferGassMQServiceInterface;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.sender.SendToMQMakeInternalTransfer;
import com.santanderuk.corinthian.hub.corinthiangass.processor.GassMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MakeInternalTransferGassMQServiceImplementation implements MakeInternalTransferGassMQServiceInterface {

    private final SendToMQMakeInternalTransfer sendItemToMQMakeInternalTransfer;
    private final XMLGen generator = new XMLGen();

    private final GassAuditValidator gassAuditValidator = new GassAuditValidator();

    public MakeInternalTransferGassMQServiceImplementation(SendToMQMakeInternalTransfer sendItemToMQMakeInternalTransfer) {
        this.sendItemToMQMakeInternalTransfer = sendItemToMQMakeInternalTransfer;
    }

    public void sendToMQMakeInternalTransfer(MakeInternalTransferGassItem makeInternalTransferGassItem) throws Exception {

        try {
            // Get a GASS Audit Record
            GassMessageProcessor gassMessageProcessor = new GassMessageProcessor();
            log.info("MakeInternalTransferGassMQServiceImplementation - > Generating Audit record");
            AuditRecord auditRecord = gassMessageProcessor.getMakeInternalTransferAuditRecord(makeInternalTransferGassItem.getGassCategorization().getAppsysid(), makeInternalTransferGassItem.getGassCategorization().getAudittrngrpid(),
                    makeInternalTransferGassItem.getGassCategorization().getTrntpname(), makeInternalTransferGassItem.getGassMessage().getOprtnsuctyp(), makeInternalTransferGassItem.getGassMessage().getClientIPAddress(),
                    makeInternalTransferGassItem.getGassMessage().getUserID(), makeInternalTransferGassItem.getGassMessage().getCustNumber(), makeInternalTransferGassItem.getGassMessage().getAccount(), makeInternalTransferGassItem.getGassMessage().getAmount(),
                    makeInternalTransferGassItem.getGassMessage().getFormattedData(), makeInternalTransferGassItem.getGassDefaultValueFields().getCompsysid(), makeInternalTransferGassItem.getGassDefaultValueFields().getDvctyp(),
                    makeInternalTransferGassItem.getGassDefaultValueFields().getOrgid(), makeInternalTransferGassItem.getGassDefaultValueFields().getOrguttp(), makeInternalTransferGassItem.getGassDefaultValueFields().getAuthcduserid(),
                    makeInternalTransferGassItem.getGassDefaultValueFields().getAuthcdcompsysid());

            log.debug("generate XML to put on MQ");
            String message = generator.retrieveXML(auditRecord);

            log.debug("formatting message");
            message = generator.prettyFormat(message);

            //validate audit message
            log.debug("validate xml message");
            gassAuditValidator.validateGASSXML(message);
            log.info("MakeInternalTransferGassMQServiceImplementation - > Audit record generated and validated");
            makeInternalTransferGassItem.setStringAuditRecord(message);
            log.debug("Mesagge: {}", message);

            log.info("MakeInternalTransferGassMQServiceImplementation - > Sending record to MQ");
            sendItemToMQMakeInternalTransfer.sendItemToMQMakeInternalTransfer(makeInternalTransferGassItem);
            log.info("MakeInternalTransferGassMQServiceImplementation - > Audit record sent to MQ OK");

        } catch (Exception e) {
            log.error("MakeInternalTransferGassMQServiceImplementation - > Error while formatting formatted data field: ", e);
            throw e;
        }
    }
}
