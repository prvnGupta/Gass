package com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.sender;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

@Slf4j
@Component
public class SendToMQMakeInternalTransfer {


    public void sendItemToMQMakeInternalTransfer(MakeInternalTransferGassItem makeInternalTransferGassItem) throws IOException, TimeoutException {
        log.info("SendToMQMakeInternalTransfer - > Creating connection to MQ");
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername(makeInternalTransferGassItem.getGassMqDetails().getMqUsername());
        factory.setPassword(makeInternalTransferGassItem.getGassMqDetails().getMqPassword());
        factory.setHost(makeInternalTransferGassItem.getGassMqDetails().getMqHost());
        if (makeInternalTransferGassItem.getGassMqDetails().getMqVirtualHost() != null && !makeInternalTransferGassItem.getGassMqDetails().getMqVirtualHost().trim().equalsIgnoreCase("")) {
            factory.setVirtualHost(makeInternalTransferGassItem.getGassMqDetails().getMqVirtualHost());
        }
        factory.setPort(makeInternalTransferGassItem.getGassMqDetails().getMqPort());
        try (Connection conn = factory.newConnection()) {
            log.debug("SendToMQMakeInternalTransfer - > Connection to MQ created OK");

            log.debug("SendToMQMakeInternalTransfer - > Creating new channel");
            Channel channel = conn.createChannel();
            log.debug("SendToMQMakeInternalTransfer - > Channel created OK");

            log.debug("SendToMQMakeInternalTransfer - > Publishing message in MQ");
            channel.basicPublish("", makeInternalTransferGassItem.getGassMqDetails().getMqQueue(),
                    MessageProperties.PERSISTENT_TEXT_PLAIN,
                    makeInternalTransferGassItem.getStringAuditRecord().getBytes(StandardCharsets.UTF_8));
            log.debug("SendToMQMakeInternalTransfer - > Message published OK");

            log.debug("SendToMQMakeInternalTransfer - > Closing channel to MQ");
            channel.close();
            log.debug("SendToMQMakeInternalTransfer - > Channel to MQ closed OK");

        } catch (IOException e) {
            log.error("SendToMQMakeInternalTransfer - > IO Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;

        } catch (TimeoutException e) {
            log.error("SendToMQMakeInternalTransfer - > TimeOut Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;
        }
    }
}
