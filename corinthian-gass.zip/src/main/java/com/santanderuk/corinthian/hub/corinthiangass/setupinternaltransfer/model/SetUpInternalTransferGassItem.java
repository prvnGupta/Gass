package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model;


import com.santanderuk.corinthian.hub.corinthiangass.common.GassCategorization;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassDefaultValueFields;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassMqDetails;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by C0229411 on 01/06/2017.
 **/


public class SetUpInternalTransferGassItem {

    private GassMqDetails gassMqDetails;
    private GassDefaultValueFields gassDefaultValueFields;
    private GassCategorization gassCategorization;
    private SetUpInternalTransferGassMessage gassMessage;
    private String stringAuditRecord;


    public SetUpInternalTransferGassItem() {
        super();
    }

    public SetUpInternalTransferGassItem(String gassMqHost, String gassMqVirtualHost, int gassMqPort, String gassMqQueue, String gassMqUsername, String gassMqPassword, String compsysid,
                                         String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid, String appsysid, String audittrngrpid, String trntpname,
                                         String oprtnsuctyp, String custNumber, String account, String amount, String clientIPAddress, String userID, SetUpInternalTransferFormattedData formattedData) {
        super();
        this.gassMqDetails = new GassMqDetails(gassMqHost, gassMqVirtualHost, gassMqPort, gassMqQueue, gassMqUsername, gassMqPassword);
        this.gassDefaultValueFields = new GassDefaultValueFields(compsysid, dvctyp, orgid, orguttp, authcduserid, authcdcompsysid);
        this.gassCategorization = new GassCategorization(appsysid, audittrngrpid, trntpname);
        this.gassMessage = new SetUpInternalTransferGassMessage(oprtnsuctyp, clientIPAddress, userID, custNumber, account, amount, formattedData);
    }

    public SetUpInternalTransferGassItem(GassMqDetails gassMqDetails, GassDefaultValueFields gassDefaultValueFields, GassCategorization gassCategorization,
                                         SetUpInternalTransferGassMessage gassMessage) {
        this.gassMqDetails = gassMqDetails;
        this.gassDefaultValueFields = gassDefaultValueFields;
        this.gassCategorization = gassCategorization;
        this.gassMessage = gassMessage;
    }

    public GassMqDetails getGassMqDetails() {
        return gassMqDetails;
    }

    public void setGassMqDetails(GassMqDetails gassMqDetails) {
        this.gassMqDetails = gassMqDetails;
    }

    public GassDefaultValueFields getGassDefaultValueFields() {
        return gassDefaultValueFields;
    }

    public void setGassDefaultValueFields(GassDefaultValueFields gassDefaultValueFields) {
        this.gassDefaultValueFields = gassDefaultValueFields;
    }

    public GassCategorization getGassCategorization() {
        return gassCategorization;
    }

    public void setGassCategorization(GassCategorization gassCategorization) {
        this.gassCategorization = gassCategorization;
    }

    public SetUpInternalTransferGassMessage getGassMessage() {
        return gassMessage;
    }

    public void setGassMessage(SetUpInternalTransferGassMessage gassMessage) {
        this.gassMessage = gassMessage;
    }

    public String getStringAuditRecord() {
        return stringAuditRecord;
    }

    public void setStringAuditRecord(String stringAuditRecord) {
        this.stringAuditRecord = stringAuditRecord;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("gassMqDetails", gassMqDetails)
                .append("gassDefaultValueFields", gassDefaultValueFields)
                .append("gassCategorization", gassCategorization)
                .append("gassMessage", gassMessage)
                .append("stringAuditRecord", stringAuditRecord)
                .toString();
    }
}
