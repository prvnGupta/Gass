package com.santanderuk.corinthian.hub.corinthiangass.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GassLoanDetails {

    private List<Loan> loan;

    private List<Loan> emptyLoanDetails = new ArrayList<>();


    public GassLoanDetails(List<Loan> loan) {
        this.loan = Optional.ofNullable(loan).orElseGet(() -> emptyLoanDetails);
    }

    public GassLoanDetails() {
    }

    public List<Loan> getLoan() {
        return Optional.ofNullable(this.loan).orElseGet(() -> emptyLoanDetails);
    }

    public void setLoan(List<Loan> loan) {
        this.loan = Optional.ofNullable(loan).orElseGet(
                () -> emptyLoanDetails);
    }

    @Override
    public String toString() {
        return new org.apache.commons.lang3.builder.ToStringBuilder(this)
                .append("loan", loan)
                .toString();
    }


}
