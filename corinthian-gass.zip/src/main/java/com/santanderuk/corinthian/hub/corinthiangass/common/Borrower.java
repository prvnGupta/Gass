package com.santanderuk.corinthian.hub.corinthiangass.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Borrower {
    private List<BorrowerElement> borrowerList;

    private List<BorrowerElement> emptyBorrowerList = new ArrayList<>();


    public Borrower(List<BorrowerElement> borrowerList) {
        this.borrowerList = Optional.ofNullable(borrowerList).orElseGet(() -> emptyBorrowerList);
    }

    public Borrower() {
    }

    public List<BorrowerElement> getBorrower() {
        return Optional.ofNullable(this.borrowerList).orElseGet(() -> emptyBorrowerList);
    }

    public void setBorrower(List<BorrowerElement> borrower) {
        this.borrowerList = Optional.ofNullable(borrower).orElseGet(
                () -> emptyBorrowerList);
    }

    @Override
    public String toString() {
        return new org.apache.commons.lang3.builder.ToStringBuilder(this)
                .append("borrowerList", borrowerList)
                .toString();
    }
}
