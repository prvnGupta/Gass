package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.implementation;

import com.santanderuk.corinthian.hub.corinthiangass.common.AuditRecord;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassAuditValidator;
import com.santanderuk.corinthian.hub.corinthiangass.common.XMLGen;
import com.santanderuk.corinthian.hub.corinthiangass.processor.GassMessageProcessor;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.SetUpRegularOverpaymentGassMQServiceInterface;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.sender.SendToMQSetUpRegularOverpayment;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 * Created by C0229411 on 01/06/2017.
 **/

@Service
@Slf4j
public class SetUpRegularOverpaymentGassMQServiceImplementation implements SetUpRegularOverpaymentGassMQServiceInterface {


    private XMLGen generator = new XMLGen();
    private GassAuditValidator gassAuditValidator = new GassAuditValidator();

    public void sendToMQSetUpRegularOverpayment(SetUpRegularOverpaymentGassItem setUpRegularOverpaymentGassItem) throws GeneralException {

        try {
            // Get a GASS Audit Record
            GassMessageProcessor gassMessageProcessor = new GassMessageProcessor();
            log.info("SetUpGassMQServiceImplementation - > Generating Audit record");
            AuditRecord auditRecord = gassMessageProcessor.getSetUpRegularOverpaymentAuditRecord(
                    setUpRegularOverpaymentGassItem.getGassCategorization().getAppsysid(),
                    setUpRegularOverpaymentGassItem.getGassCategorization().getAudittrngrpid(),
                    setUpRegularOverpaymentGassItem.getGassCategorization().getTrntpname(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getOprtnsuctyp(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getClientIPAddress(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getUserID(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getCustNumber(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getAccount(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getAmount(),
                    setUpRegularOverpaymentGassItem.getGassMessage().getFormattedData(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getCompsysid(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getDvctyp(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getOrgid(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getOrguttp(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getAuthcduserid(),
                    setUpRegularOverpaymentGassItem.getGassDefaultValueFields().getAuthcdcompsysid());


            log.debug("generate XML to put on MQ");
            String message = generator.retrieveXML(auditRecord);

            log.debug("formatting message");
            message = generator.prettyFormat(message);

            //validate audit message
            log.debug("validate xml message");
            gassAuditValidator.validateGASSXML(message);
            log.info("SetUpGassMQServiceImplementation - > Audit record generated and validated");
            setUpRegularOverpaymentGassItem.setStringAuditRecord(message);
            log.debug("Mesagge: {}", message);

            log.info("SetUpGassMQServiceImplementation - > Sending record to MQ");
            new SendToMQSetUpRegularOverpayment(setUpRegularOverpaymentGassItem);
            log.info("SetUpGassMQServiceImplementation - > Audit record sent to MQ OK");

        } catch (Exception e) {
            log.error("SetUpGassMQServiceImplementation - > Error while formatting formatted data field: ", e);
            throw new GeneralException("GASS_ERROR", "ERROR WHILE SENDING RECORD TO RABBIT MQ", e);
        }
    }


}
