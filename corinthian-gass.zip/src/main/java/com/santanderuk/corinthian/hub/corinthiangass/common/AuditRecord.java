package com.santanderuk.corinthian.hub.corinthiangass.common;

public class AuditRecord {
    protected String formatteddata;
    protected String userid;
    protected String appsysid;
    protected String audittrngrpid;
    protected String audittrntpname;
    protected String oprtnsuctyp;
    protected String keyhldgref;
    protected String keyaltuid;
    protected String keyuserid;
    protected String orgid;
    protected String keyamt;
    protected String dvctyp;
    protected String orguttp;
    protected String compsysid;
    protected String dvcid;
    protected String authcduserid;
    protected String authcdcompsysid;
    protected String trncltref;

    /**
     * Constructor
     */
    public AuditRecord() {
    }

    /**
     * getKeyamt
     *
     * @return
     */
    public String getKeyamt() {
        return this.keyamt;
    }

    /**
     * setKeyamt
     *
     * @param keyamt
     */
    public void setKeyamt(String keyamt) {
        this.keyamt = keyamt;
    }

    /**
     * getDvctyp
     *
     * @return
     */
    public String getDvctyp() {
        return this.dvctyp;
    }

    /**
     * setDvctyp
     *
     * @param dvctyp
     */
    public void setDvctyp(String dvctyp) {
        this.dvctyp = dvctyp;
    }

    /**
     * getOrguttp
     *
     * @return
     */
    public String getOrguttp() {
        return this.orguttp;
    }

    /**
     * setOrguttp
     *
     * @param orguttp
     */
    public void setOrguttp(String orguttp) {
        this.orguttp = orguttp;
    }

    /**
     * getCompsysid
     *
     * @return
     */
    public String getCompsysid() {
        return this.compsysid;
    }

    /**
     * setCompsysid
     *
     * @param compsysid
     */
    public void setCompsysid(String compsysid) {
        this.compsysid = compsysid;
    }

    /**
     * getFormattedData
     *
     * @return
     */
    public String getFormattedData() {
        return this.formatteddata;
    }

    /**
     * setFormattedData
     *
     * @param formatteddata
     */
    public void setFormattedData(String formatteddata) {
        this.formatteddata = formatteddata;
    }

    /**
     * getUserID
     *
     * @return
     */
    public String getUserID() {
        return this.userid;
    }

    /**
     * setUserID
     *
     * @param userid
     */
    public void setUserID(String userid) {
        this.userid = userid;
    }

    /**
     * getAppsysid
     *
     * @return
     */
    public String getAppsysid() {
        return this.appsysid;
    }

    /**
     * setAppsysid
     *
     * @param appsysid
     */
    public void setAppsysid(String appsysid) {
        this.appsysid = appsysid;
    }

    /**
     * getAudittrngrpid
     *
     * @return
     */
    public String getAudittrngrpid() {
        return this.audittrngrpid;
    }

    /**
     * setAudittrngrpid
     *
     * @param audittrngrpid
     */
    public void setAudittrngrpid(String audittrngrpid) {
        this.audittrngrpid = audittrngrpid;
    }

    /**
     * getAudittrntpname
     *
     * @return
     */
    public String getAudittrntpname() {
        return this.audittrntpname;
    }

    /**
     * setAudittrntpname
     *
     * @param audittrntpname
     */
    public void setAudittrntpname(String audittrntpname) {
        this.audittrntpname = audittrntpname;
    }

    /**
     * getOprtnsuctyp
     *
     * @return
     */
    public String getOprtnsuctyp() {
        return this.oprtnsuctyp;
    }

    /**
     * setOprtnsuctyp
     *
     * @param oprtnsuctyp
     */
    public void setOprtnsuctyp(String oprtnsuctyp) {
        this.oprtnsuctyp = oprtnsuctyp;
    }

    /**
     * getKeyhldgref
     *
     * @return
     */
    public String getKeyhldgref() {
        return this.keyhldgref;
    }

    /**
     * setKeyhldgref
     *
     * @param keyhldgref
     */
    public void setKeyhldgref(String keyhldgref) {
        this.keyhldgref = keyhldgref;
    }

    /**
     * getOrgid
     *
     * @return
     */
    public String getOrgid() {
        return this.orgid;
    }

    /**
     * setOrgid
     *
     * @param orgid
     */
    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    /**
     * getDvcid
     *
     * @return
     */
    public String getDvcid() {
        return this.dvcid;
    }

    /**
     * setDvcid
     *
     * @param dvcid
     */
    public void setDvcid(String dvcid) {
        this.dvcid = dvcid;
    }

    /**
     * getKeyAltUID
     *
     * @return
     */
    public String getKeyAltUID() {
        return this.keyaltuid;
    }

    /**
     * setKeyAltUID
     *
     * @param keyaltuid
     */
    public void setKeyAltUID(String keyaltuid) {
        this.keyaltuid = keyaltuid;
    }

    /**
     * getKeyUserID
     *
     * @return
     */
    public String getKeyUserID() {
        return this.keyuserid;
    }

    /**
     * setKeyUserID
     *
     * @param keyuserid
     */
    public void setKeyUserID(String keyuserid) {
        this.keyuserid = keyuserid;
    }

    /**
     * getAuthcduserid
     *
     * @return
     */
    public String getAuthcduserid() {
        return authcduserid;
    }

    /**
     * setAuthcduserid
     *
     * @param authcduserid
     */
    public void setAuthcduserid(String authcduserid) {
        this.authcduserid = authcduserid;
    }

    /**
     * getAuthcdcompsysid
     *
     * @return
     */
    public String getAuthcdcompsysid() {
        return authcdcompsysid;
    }

    /**
     * setAuthcdcompsysid
     *
     * @param authcdompsysid
     */
    public void setAuthcdcompsysid(String authcdompsysid) {
        this.authcdcompsysid = authcdompsysid;
    }

    /**
     * getTrncltref
     *
     * @return
     */
    public String getTrncltref() {
        return trncltref;
    }

    /**
     * setTrncltref
     *
     * @param trncltref
     */
    public void setTrncltref(String trncltref) {
        this.trncltref = trncltref;
    }
}
