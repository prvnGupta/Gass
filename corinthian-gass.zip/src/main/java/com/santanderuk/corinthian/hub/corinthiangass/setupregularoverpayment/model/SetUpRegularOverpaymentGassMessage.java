package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by C0229411 on 07/06/2017.
 **/

@Getter
@Setter
public class SetUpRegularOverpaymentGassMessage {

    private String oprtnsuctyp;
    private String clientIPAddress;
    private String userID;
    private String custNumber;
    private String account;
    private String amount;
    private SetUpRegularOverpaymentFormattedData formattedData;

    public SetUpRegularOverpaymentGassMessage(String oprtnsuctyp, String clientIPAddress, String userID, String custNumber, String account, String amount, SetUpRegularOverpaymentFormattedData formattedData) {
        this.oprtnsuctyp = oprtnsuctyp;
        this.clientIPAddress = clientIPAddress;
        this.userID = userID;
        this.custNumber = custNumber;
        this.account = account;
        this.amount = amount;
        this.formattedData = formattedData;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("oprtnsuctyp", oprtnsuctyp)
                .append("clientIPAddress", clientIPAddress)
                .append("userID", userID)
                .append("custNumber", custNumber)
                .append("account", account)
                .append("amount", amount)
                .append("formattedData", formattedData)
                .toString();
    }
}
