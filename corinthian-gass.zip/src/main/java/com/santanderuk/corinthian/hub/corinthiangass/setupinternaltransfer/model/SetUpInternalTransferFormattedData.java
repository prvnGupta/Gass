package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model;

import com.santanderuk.corinthian.hub.corinthiangass.common.Borrower;
import com.santanderuk.corinthian.hub.corinthiangass.common.BorrowerElement;
import com.santanderuk.corinthian.hub.corinthiangass.common.Loan;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassLoanDetails;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataAudit")
@XmlType(propOrder = {"borrowerList", "originAccount", "destinationAccount", "multiChannelContractId",
        "earlyRepaymentChargeIndicator", "earlyRepaymentChargeAmount", "overpaymentAmount",
        "totalPaymentAmount", "loanDetails"})
public class SetUpInternalTransferFormattedData {

    private Borrower borrowerList;
    private String originAccount;
    private String destinationAccount;
    private String multiChannelContractId;
    private String earlyRepaymentChargeIndicator;
    private String earlyRepaymentChargeAmount;
    private String overpaymentAmount;
    private String totalPaymentAmount;
    private GassLoanDetails loanDetails;

    public Borrower getBorrowerList() {
        return borrowerList;
    }

    public void setBorrowerList(Borrower borrowerList) {
        this.borrowerList = borrowerList;
    }


    public String getOriginAccount() {
        return originAccount;
    }

    public void setOriginAccount(String originAccount) {
        this.originAccount = originAccount;
    }

    public String getDestinationAccount() {
        return destinationAccount;
    }

    public void setDestinationAccount(String destinationAccount) {
        this.destinationAccount = destinationAccount;
    }

    public String getMultiChannelContractId() {
        return multiChannelContractId;
    }

    public void setMultiChannelContractId(String multiChannelContractId) {
        this.multiChannelContractId = multiChannelContractId;
    }

    public String getEarlyRepaymentChargeIndicator() {
        return earlyRepaymentChargeIndicator;
    }

    public void setEarlyRepaymentChargeIndicator(String earlyRepaymentChargeIndicator) {
        this.earlyRepaymentChargeIndicator = earlyRepaymentChargeIndicator;
    }

    public String getEarlyRepaymentChargeAmount() {
        return earlyRepaymentChargeAmount;
    }

    public void setEarlyRepaymentChargeAmount(String earlyRepaymentChargeAmount) {
        this.earlyRepaymentChargeAmount = earlyRepaymentChargeAmount;
    }

    public String getOverpaymentAmount() {
        return overpaymentAmount;
    }

    public void setOverpaymentAmount(String overpaymentAmount) {
        this.overpaymentAmount = overpaymentAmount;
    }

    public String getTotalPaymentAmount() {
        return totalPaymentAmount;
    }

    public void setTotalPaymentAmount(String totalPaymentAmount) {
        this.totalPaymentAmount = totalPaymentAmount;
    }

    public GassLoanDetails getLoanDetails() {
        return loanDetails;
    }

    public void setLoanDetails(GassLoanDetails loanDetails) {
        this.loanDetails = loanDetails;
    }

    private void beforeMarshal(Marshaller marshaller) {

        if (null == borrowerList) {
            List<BorrowerElement> borrower = new ArrayList<>();
            borrower.add(new BorrowerElement("", "", ""));
            borrowerList = new Borrower(borrower);
        }
        if (null == originAccount) {
            originAccount = "";
        }

        if (null == destinationAccount) {
            destinationAccount = "";
        }

        if (null == multiChannelContractId) {
            multiChannelContractId = "";
        }

        if (null == earlyRepaymentChargeIndicator) {
            earlyRepaymentChargeIndicator = "";
        }

        if (null == earlyRepaymentChargeAmount) {
            earlyRepaymentChargeAmount = "";
        }

        if (null == overpaymentAmount) {
            overpaymentAmount = "";
        }

        if (null == totalPaymentAmount) {
            totalPaymentAmount = "";
        }

        if (null == loanDetails) {
            List<Loan> loan = new ArrayList<>();
            loan.add(new Loan("", 0, "", "", "", "", "", "", ""));
            loanDetails = new GassLoanDetails(loan);
        }
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("borrowerList", borrowerList)
                .append("originAccount", originAccount)
                .append("destinationAccount", destinationAccount)
                .append("multiChannelContractId", multiChannelContractId)
                .append("earlyRepaymentChargeIndicator", earlyRepaymentChargeIndicator)
                .append("earlyRepaymentChargeAmount", earlyRepaymentChargeAmount)
                .append("overpaymentAmount", overpaymentAmount)
                .append("totalPaymentAmount", totalPaymentAmount)
                .append("loanDetails", loanDetails)
                .toString();
    }
}
