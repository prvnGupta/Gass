package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.Marshaller;

public class Loan {

    private String loanSchema;
    private int loanApplicationSequenceNumber;
    private String optionChosen;
    private String loanErcAmount;
    private String loanOverpaymentAmount;
    private String loanTotalPaymentAmount;
    private String newMonthlyPayment;
    private String newLoanEndDate;
    private String interestSaving;

    public Loan() {
    }

    public Loan(String loanSchema, int loanApplicationSequenceNumber, String optionChosen, String loanErcAmount, String loanOverpaymentAmount, String loanTotalPaymentAmount, String newMonthlyPayment, String newLoanEndDate, String interestSaving) {
        this.loanSchema = loanSchema;
        this.loanApplicationSequenceNumber = loanApplicationSequenceNumber;
        this.optionChosen = optionChosen;
        this.loanErcAmount = loanErcAmount;
        this.loanOverpaymentAmount = loanOverpaymentAmount;
        this.loanTotalPaymentAmount = loanTotalPaymentAmount;
        this.newMonthlyPayment = newMonthlyPayment;
        this.newLoanEndDate = newLoanEndDate;
        this.interestSaving = interestSaving;
    }

    public String getLoanSchema() {
        return loanSchema;
    }

    public void setLoanSchema(String loanSchema) {
        this.loanSchema = loanSchema;
    }

    public int getLoanApplicationSequenceNumber() {
        return loanApplicationSequenceNumber;
    }

    public void setLoanApplicationSequenceNumber(int loanApplicationSequenceNumber) {
        this.loanApplicationSequenceNumber = loanApplicationSequenceNumber;
    }

    public String getOptionChosen() {
        return optionChosen;
    }

    public void setOptionChosen(String optionChosen) {
        this.optionChosen = optionChosen;
    }

    public String getLoanErcAmount() {
        return loanErcAmount;
    }

    public void setLoanErcAmount(String loanErcAmount) {
        this.loanErcAmount = loanErcAmount;
    }

    public String getLoanOverpaymentAmount() {
        return loanOverpaymentAmount;
    }

    public void setLoanOverpaymentAmount(String loanOverpaymentAmount) {
        this.loanOverpaymentAmount = loanOverpaymentAmount;
    }

    public String getLoanTotalPaymentAmount() {
        return loanTotalPaymentAmount;
    }

    public void setLoanTotalPaymentAmount(String loanTotalPaymentAmount) {
        this.loanTotalPaymentAmount = loanTotalPaymentAmount;
    }

    public String getNewMonthlyPayment() {
        return newMonthlyPayment;
    }

    public void setNewMonthlyPayment(String newMonthlyPayment) {
        this.newMonthlyPayment = newMonthlyPayment;
    }

    public String getNewLoanEndDate() {
        return newLoanEndDate;
    }

    public void setNewLoanEndDate(String newLoanEndDate) {
        this.newLoanEndDate = newLoanEndDate;
    }

    public String getInterestSaving() {
        return interestSaving;
    }

    public void setInterestSaving(String interestSaving) {
        this.interestSaving = interestSaving;
    }

    private void beforeMarshal(Marshaller marshaller) {

        if (null == loanSchema) {
            loanSchema = "";
        }

        if (0 == loanApplicationSequenceNumber) {
            loanApplicationSequenceNumber = 0;
        }

        if (optionChosen.equalsIgnoreCase("t")) {
            optionChosen = "Reduce Term";
        }

        if (optionChosen.equalsIgnoreCase("m")) {
            optionChosen = "Reduce Monthly Payment";
        }

        if (null == loanErcAmount) {
            loanErcAmount = "";
        }

        if (null == loanOverpaymentAmount) {
            loanOverpaymentAmount = "";
        }

        if (null == loanTotalPaymentAmount) {
            loanTotalPaymentAmount = "";
        }

        if (null == newMonthlyPayment) {
            newMonthlyPayment = "";
        }

        if (null == newLoanEndDate) {
            newLoanEndDate = "";
        }

        if (null == interestSaving) {
            interestSaving = "";
        }
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("loanSchema", loanSchema)
                .append("loanApplicationSequenceNumber", loanApplicationSequenceNumber)
                .append("optionChosen", optionChosen)
                .append("loanErcAmount", loanErcAmount)
                .append("loanOverpaymentAmount", loanOverpaymentAmount)
                .append("loanTotalPaymentAmount", loanTotalPaymentAmount)
                .append("newMonthlyPayment", newMonthlyPayment)
                .append("newMortgageTerm", newLoanEndDate)
                .append("interestSaving", interestSaving)
                .toString();
    }
}
