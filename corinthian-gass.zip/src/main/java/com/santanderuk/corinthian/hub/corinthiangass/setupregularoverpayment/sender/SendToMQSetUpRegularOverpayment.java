package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.sender;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentGassItem;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

/**
 * Created by C0229411 on 01/06/2017.
 **/

@Slf4j
public class SendToMQSetUpRegularOverpayment {

    public SendToMQSetUpRegularOverpayment(SetUpRegularOverpaymentGassItem setUpRegularOverpaymentGassItem) throws IOException, TimeoutException {
        log.info("SendToMQSetUpInternalTransfer - > Creating connection to MQ");
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername(setUpRegularOverpaymentGassItem.getGassMqDetails().getMqUsername());
        factory.setPassword(setUpRegularOverpaymentGassItem.getGassMqDetails().getMqPassword());
        factory.setHost(setUpRegularOverpaymentGassItem.getGassMqDetails().getMqHost());
        if (setUpRegularOverpaymentGassItem.getGassMqDetails().getMqVirtualHost() != null && !setUpRegularOverpaymentGassItem.getGassMqDetails().getMqVirtualHost().trim().equalsIgnoreCase("")) {
            factory.setVirtualHost(setUpRegularOverpaymentGassItem.getGassMqDetails().getMqVirtualHost());
        }
        factory.setPort(setUpRegularOverpaymentGassItem.getGassMqDetails().getMqPort());
        try (Connection conn = factory.newConnection()) {
            log.debug("SendToMQSetUpInternalTransfer - > Connection to MQ created OK");

            log.debug("SendToMQSetUpInternalTransfer - > Creating new channel");
            Channel channel = conn.createChannel();
            log.debug("SendToMQSetUpInternalTransfer - > Channel created OK");

            log.debug("SendToMQSetUpInternalTransfer - > Publishing message in MQ.");
            channel.basicPublish("", setUpRegularOverpaymentGassItem.getGassMqDetails().getMqQueue(),
                    MessageProperties.PERSISTENT_TEXT_PLAIN,
                    setUpRegularOverpaymentGassItem.getStringAuditRecord().getBytes(StandardCharsets.UTF_8));
            log.debug("SendToMQSetUpInternalTransfer - > Message published OK");

            log.debug("SendToMQSetUpInternalTransfer - > Closing channel to MQ");
            channel.close();
            log.debug("SendToMQSetUpInternalTransfer - > Channel to MQ closed OK");

        } catch (IOException e) {
            log.error("SendToMQSetUpInternalTransfer - > IO Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;

        } catch (TimeoutException e) {
            log.error("SendToMQSetUpInternalTransfer - > TimeOut Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;
        }
    }
}
