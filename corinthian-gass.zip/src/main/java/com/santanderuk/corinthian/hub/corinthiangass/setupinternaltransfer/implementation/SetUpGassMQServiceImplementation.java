package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.implementation;

import com.santanderuk.corinthian.hub.corinthiangass.common.AuditRecord;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassAuditValidator;
import com.santanderuk.corinthian.hub.corinthiangass.common.XMLGen;
import com.santanderuk.corinthian.hub.corinthiangass.processor.GassMessageProcessor;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.SetUpInternalTransferGassMQServiceInterface;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.sender.SendToMQSetUpInternalTransfer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class SetUpGassMQServiceImplementation implements SetUpInternalTransferGassMQServiceInterface {

    private static final Logger log = LoggerFactory.getLogger(SetUpGassMQServiceImplementation.class);
    private final SendToMQSetUpInternalTransfer sendItemToMQSetUpInternalTransfer;
    private XMLGen generator = new XMLGen();
    private GassAuditValidator gassAuditValidator = new GassAuditValidator();

    public SetUpGassMQServiceImplementation(SendToMQSetUpInternalTransfer sendItemToMQSetUpInternalTransfer) {
        this.sendItemToMQSetUpInternalTransfer = sendItemToMQSetUpInternalTransfer;
    }

    public void sendToMQSetUpInternalTransfer(SetUpInternalTransferGassItem setUpInternalTransferGassItem) throws Exception {

        try {
            // Get a GASS Audit Record
            GassMessageProcessor gassMessageProcessor = new GassMessageProcessor();
            log.info("SetUpGassMQServiceImplementation - > Generating Audit record");
            AuditRecord auditRecord = gassMessageProcessor.getSetUpInternalTransferAuditRecord(
                    setUpInternalTransferGassItem.getGassCategorization().getAppsysid(),
                    setUpInternalTransferGassItem.getGassCategorization().getAudittrngrpid(),
                    setUpInternalTransferGassItem.getGassCategorization().getTrntpname(),
                    setUpInternalTransferGassItem.getGassMessage().getOprtnsuctyp(),
                    setUpInternalTransferGassItem.getGassMessage().getClientIPAddress(),
                    setUpInternalTransferGassItem.getGassMessage().getUserID(),
                    setUpInternalTransferGassItem.getGassMessage().getCustNumber(),
                    setUpInternalTransferGassItem.getGassMessage().getAccount(),
                    setUpInternalTransferGassItem.getGassMessage().getAmount(),
                    setUpInternalTransferGassItem.getGassMessage().getFormattedData(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getCompsysid(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getDvctyp(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getOrgid(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getOrguttp(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getAuthcduserid(),
                    setUpInternalTransferGassItem.getGassDefaultValueFields().getAuthcdcompsysid());


            log.debug("generate XML to put on MQ");
            String message = generator.retrieveXML(auditRecord);

            log.debug("formatting message");
            message = generator.prettyFormat(message);

            //validate audit message
            log.debug("validate xml message");
            gassAuditValidator.validateGASSXML(message);
            log.info("SetUpGassMQServiceImplementation - > Audit record generated and validated");
            setUpInternalTransferGassItem.setStringAuditRecord(message);
            log.debug("Mesagge: {}", message);

            log.info("SetUpGassMQServiceImplementation - > Sending record to MQ");
            sendItemToMQSetUpInternalTransfer.sendItemToMQSetUpInternalTransfer(setUpInternalTransferGassItem);
            log.info("SetUpGassMQServiceImplementation - > Audit record sent to MQ OK");

        } catch (Exception e) {
            log.error("SetUpGassMQServiceImplementation - > Error while formatting formatted data field: ", e);
            throw e;
        }
    }


}
