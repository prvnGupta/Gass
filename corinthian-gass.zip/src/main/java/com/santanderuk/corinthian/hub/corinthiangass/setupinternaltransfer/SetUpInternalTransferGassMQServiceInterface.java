package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer;

import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;

/**
 * Created by C0229411 on 05/06/2017.
 **/
public interface SetUpInternalTransferGassMQServiceInterface {
    void sendToMQSetUpInternalTransfer(SetUpInternalTransferGassItem setUpInternalTransferGassItem) throws Exception;
//    void sendToMQMakeInternalTransfer(SetUpInternalTransferGassItem setUpInternalTransferGassItem)throws Exception;
//    void sendToMQDebitCardPayment(SetUpInternalTransferGassItem setUpInternalTransferGassItem)throws Exception;
}
