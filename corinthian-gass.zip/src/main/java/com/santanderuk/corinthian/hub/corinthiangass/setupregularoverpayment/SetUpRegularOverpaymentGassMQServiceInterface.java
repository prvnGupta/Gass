package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment;

import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentGassItem;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

/**
 * Created by C0229411 on 05/06/2017.
 **/
public interface SetUpRegularOverpaymentGassMQServiceInterface {
    void sendToMQSetUpRegularOverpayment(SetUpRegularOverpaymentGassItem setUpRegularOverpaymentGassItem) throws GeneralException;

}
