package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model;

import com.santanderuk.corinthian.hub.corinthiangass.common.Borrower;
import com.santanderuk.corinthian.hub.corinthiangass.common.BorrowerElement;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataAudit")
@XmlType(propOrder = {"customerNumber", "borrowerList", "multiChannelContractId", "mortgageAccountNumber",
        "contractualMonthlyPaymentAmount", "overpaymentAmount", "directDebitTotalAmount", "startDate", "endDate", "numberOfPayments",
        "overpaymentEffect", "originAccount", "destinationAccount", "formattedLoans"})
@Getter
@Setter
public class SetUpRegularOverpaymentFormattedData {

    private String customerNumber;
    private Borrower borrowerList;
    private String multiChannelContractId;
    private String mortgageAccountNumber;
    private String contractualMonthlyPaymentAmount;
    private String overpaymentAmount;
    private String directDebitTotalAmount;
    private String startDate;
    private String endDate;
    private String numberOfPayments;
    private String overpaymentEffect;
    private String originAccount;
    private String destinationAccount;
    private List<FormattedLoan> formattedLoans;


    private void beforeMarshal(Marshaller marshaller) {
        if (null == customerNumber) {
            customerNumber = "";
        }

        if (null == borrowerList) {
            List<BorrowerElement> borrower = new ArrayList<>();
            borrower.add(new BorrowerElement("", "", ""));
            borrowerList = new Borrower(borrower);
        }

        if (null == multiChannelContractId) {
            multiChannelContractId = "";
        }

        if (null == mortgageAccountNumber) {
            mortgageAccountNumber = "";
        }

        if (null == contractualMonthlyPaymentAmount) {
            contractualMonthlyPaymentAmount = "";
        }

        if (null == overpaymentAmount) {
            overpaymentAmount = "";
        }

        if (null == directDebitTotalAmount) {
            directDebitTotalAmount = "";
        }

        if (null == startDate) {
            startDate = "";
        }

        if (null == endDate) {
            endDate = "";
        }

        if (null == numberOfPayments) {
            numberOfPayments = "";
        }

        if (null == overpaymentEffect) {
            overpaymentEffect = "";
        } else {
            if (overpaymentEffect.equalsIgnoreCase("t")) {
                overpaymentEffect = "Reduce Term";
            }

            if (overpaymentEffect.equalsIgnoreCase("m")) {
                overpaymentEffect = "Reduce Monthly Payment";
            }
        }

        if (null == originAccount) {
            originAccount = "";
        }

        if (null == destinationAccount) {
            destinationAccount = "";
        }
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("customerNumber", customerNumber)
                .append("borrowerList", borrowerList)
                .append("multiChannelContractId", multiChannelContractId)
                .append("mortgageAccountNumber", mortgageAccountNumber)
                .append("contractualMonthlyPaymentAmount", contractualMonthlyPaymentAmount)
                .append("overpaymentAmount", overpaymentAmount)
                .append("directDebitTotalAmount", directDebitTotalAmount)
                .append("startDate", startDate)
                .append("endDate", endDate)
                .append("numberOfPayments", numberOfPayments)
                .append("overpaymentEffect", overpaymentEffect)
                .append("originAccount", originAccount)
                .append("destinationAccount", destinationAccount)
                .toString();
    }
}
