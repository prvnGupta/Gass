package com.santanderuk.corinthian.hub.corinthiangass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by C0229411 on 08/06/2017.
 **/

@SpringBootApplication
public class CorinthianGassApplication {
    public static void main(String[] args) {
        SpringApplication.run(CorinthianGassApplication.class, args);
    }
}
