package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

public class GassAuditValidator {

    private static final Logger LOG = LoggerFactory.getLogger(GassAuditValidator.class);

    /**
     * validateGASSXML
     *
     * @param gassXML
     */
    public void validateGASSXML(String gassXML) {

        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");

            ClassPathResource mqAuditXml = new ClassPathResource("/MQAuditXML.xsd");
            InputStream inputStream = mqAuditXml.getInputStream();
            Source schemaSource = new StreamSource(inputStream);

            Schema schema = schemaFactory.newSchema(schemaSource);

            Validator validator = schema.newValidator();

            Source xmlsource = new StreamSource(new StringReader(gassXML));

            validator.validate(xmlsource);

        } catch (IOException e) {
            LOG.error(e.getMessage());
            throw new RuntimeException(e);
        } catch (SAXException e) {
            LOG.error(e.getMessage());
            throw new RuntimeException(e);
        }
    }

}
