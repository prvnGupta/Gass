package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.bind.Marshaller;

public class BorrowerElement {

    private String name;
    private String customerType;
    private String customerCode;

    public BorrowerElement() {
    }

    public BorrowerElement(String name, String customerType, String customerCode) {
        this.name = name;
        this.customerCode = customerCode;
        this.customerType = customerType;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private void beforeMarshal(Marshaller marshaller) {
        if (null == name) {
            name = "";
        }

        if (null == customerCode) {
            customerCode = "";
        }

        if (null == customerType) {
            customerType = "";
        }
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("name", name)
                .append("customerType", customerType)
                .append("customerCode", customerCode)
                .toString();
    }
}
