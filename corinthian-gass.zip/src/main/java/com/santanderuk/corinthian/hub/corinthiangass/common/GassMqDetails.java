package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class GassMqDetails {
    private String mqHost;
    private String mqVirtualHost;
    private int mqPort;
    private String mqQueue;
    private String mqUsername;
    private String mqPassword;

    public GassMqDetails(String mqHost, String mqVirtualHost, int mqPort, String mqQueue, String mqUsername, String mqPassword) {
        this.mqHost = mqHost;
        this.mqVirtualHost = mqVirtualHost;
        this.mqPort = mqPort;
        this.mqQueue = mqQueue;
        this.mqUsername = mqUsername;
        this.mqPassword = mqPassword;
    }

    public String getMqHost() {
        return mqHost;
    }

    public void setMqHost(String mqHost) {
        this.mqHost = mqHost;
    }

    public int getMqPort() {
        return mqPort;
    }

    public void setMqPort(int mqPort) {
        this.mqPort = mqPort;
    }

    public String getMqQueue() {
        return mqQueue;
    }

    public void setMqQueue(String mqQueue) {
        this.mqQueue = mqQueue;
    }

    public String getMqUsername() {
        return mqUsername;
    }

    public void setMqUsername(String mqUsername) {
        this.mqUsername = mqUsername;
    }

    public String getMqPassword() {
        return mqPassword;
    }

    public void setMqPassword(String mqPassword) {
        this.mqPassword = mqPassword;
    }

    public String getMqVirtualHost() {
        return mqVirtualHost;
    }

    public void setMqVirtualHost(String mqVirtualHost) {
        this.mqVirtualHost = mqVirtualHost;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("mqHost", mqHost)
                .append("mqVirtualHost", mqVirtualHost)
                .append("mqPort", mqPort)
                .append("mqQueue", mqQueue)
                .append("mqUsername", mqUsername)
                .append("mqPassword", mqPassword)
                .toString();
    }
}
