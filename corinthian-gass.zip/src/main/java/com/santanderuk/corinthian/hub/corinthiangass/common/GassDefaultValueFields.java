package com.santanderuk.corinthian.hub.corinthiangass.common;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class GassDefaultValueFields {

    private String compsysid;
    private String dvctyp;
    private String orgid;
    private String orguttp;
    private String authcduserid;
    private String authcdcompsysid;

    public GassDefaultValueFields(String compsysid, String dvctyp, String orgid, String orguttp, String authcduserid, String authcdcompsysid) {
        this.compsysid = compsysid;
        this.dvctyp = dvctyp;
        this.orgid = orgid;
        this.orguttp = orguttp;
        this.authcduserid = authcduserid;
        this.authcdcompsysid = authcdcompsysid;
    }

    public String getCompsysid() {
        return compsysid;
    }

    public void setCompsysid(String compsysid) {
        this.compsysid = compsysid;
    }

    public String getDvctyp() {
        return dvctyp;
    }

    public void setDvctyp(String dvctyp) {
        this.dvctyp = dvctyp;
    }

    public String getOrgid() {
        return orgid;
    }

    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    public String getOrguttp() {
        return orguttp;
    }

    public void setOrguttp(String orguttp) {
        this.orguttp = orguttp;
    }

    public String getAuthcduserid() {
        return authcduserid;
    }

    public void setAuthcduserid(String authcduserid) {
        this.authcduserid = authcduserid;
    }

    public String getAuthcdcompsysid() {
        return authcdcompsysid;
    }

    public void setAuthcdcompsysid(String authcdcompsysid) {
        this.authcdcompsysid = authcdcompsysid;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("compsysid", compsysid)
                .append("dvctyp", dvctyp)
                .append("orgid", orgid)
                .append("orguttp", orguttp)
                .append("authcduserid", authcduserid)
                .append("authcdcompsysid", authcdcompsysid)
                .toString();
    }
}
