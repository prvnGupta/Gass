package com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FormattedLoan extends ModelBase {

    private String loanSchema;
    private String appSequenceNumber;
    private String loanType;
    private int orderId;
}
