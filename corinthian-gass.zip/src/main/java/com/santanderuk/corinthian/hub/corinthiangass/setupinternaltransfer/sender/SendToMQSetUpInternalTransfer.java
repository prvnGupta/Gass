package com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.sender;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

@Component
@Slf4j
public class SendToMQSetUpInternalTransfer {

    public void sendItemToMQSetUpInternalTransfer(SetUpInternalTransferGassItem setUpInternalTransferGassItem) throws IOException, TimeoutException {
        log.info("SendToMQSetUpInternalTransfer - > Creating connection to MQ");
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername(setUpInternalTransferGassItem.getGassMqDetails().getMqUsername());
        factory.setPassword(setUpInternalTransferGassItem.getGassMqDetails().getMqPassword());
        factory.setHost(setUpInternalTransferGassItem.getGassMqDetails().getMqHost());
        if (setUpInternalTransferGassItem.getGassMqDetails().getMqVirtualHost() != null && !setUpInternalTransferGassItem.getGassMqDetails().getMqVirtualHost().trim().equalsIgnoreCase("")) {
            factory.setVirtualHost(setUpInternalTransferGassItem.getGassMqDetails().getMqVirtualHost());
        }
        factory.setPort(setUpInternalTransferGassItem.getGassMqDetails().getMqPort());
        try (Connection conn = factory.newConnection()) {
            log.debug("SendToMQSetUpInternalTransfer - > Connection to MQ created OK");

            log.debug("SendToMQSetUpInternalTransfer - > Creating new channel");
            Channel channel = conn.createChannel();
            log.debug("SendToMQSetUpInternalTransfer - > Channel created OK");

            log.debug("SendToMQSetUpInternalTransfer - > Publishing message in MQ.");
            channel.basicPublish("", setUpInternalTransferGassItem.getGassMqDetails().getMqQueue(),
                    MessageProperties.PERSISTENT_TEXT_PLAIN,
                    setUpInternalTransferGassItem.getStringAuditRecord().getBytes(StandardCharsets.UTF_8));
            log.debug("SendToMQSetUpInternalTransfer - > Message published OK");

            log.debug("SendToMQSetUpInternalTransfer - > Closing channel to MQ");
            channel.close();
            log.debug("SendToMQSetUpInternalTransfer - > Channel to MQ closed OK");

        } catch (IOException e) {
            log.error("SendToMQSetUpInternalTransfer - > IO Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;

        } catch (TimeoutException e) {
            log.error("SendToMQSetUpInternalTransfer - > TimeOut Error while sending Audit Record to MQ: {}", e.getMessage(), e);
            throw e;
        }
    }
}
