package com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.implementation;

import com.santanderuk.corinthian.hub.corinthiangass.GassBaseTest;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.sender.SendToMQMakeInternalTransfer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(SpringExtension.class)
public class MakeInternalTransferGassMQServiceImplementationTest extends GassBaseTest {
    MakeInternalTransferGassMQServiceImplementation makeInternalTransferGassMQServiceImplementation;

    @Mock
    SendToMQMakeInternalTransfer sendItemToMQMakeInternalTransfer;

    @BeforeEach
    public void setUp() {
        makeInternalTransferGassMQServiceImplementation = new MakeInternalTransferGassMQServiceImplementation(sendItemToMQMakeInternalTransfer);
    }

    @Test
    public void sendToMQSetUpInternalTransfer_OK() throws Exception {
        Mockito.doNothing().when(sendItemToMQMakeInternalTransfer).sendItemToMQMakeInternalTransfer(any());
        makeInternalTransferGassMQServiceImplementation.sendToMQMakeInternalTransfer(genericMakeInternalTransferGassItem());
    }

}
