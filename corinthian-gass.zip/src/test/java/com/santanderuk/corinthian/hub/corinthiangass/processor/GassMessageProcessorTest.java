package com.santanderuk.corinthian.hub.corinthiangass.processor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.santanderuk.corinthian.hub.corinthiangass.GassBaseTest.genericMakeInternalTransferFormattedData;
import static com.santanderuk.corinthian.hub.corinthiangass.GassBaseTest.genericSetUpInternalTransferFormattedData;
import static org.junit.jupiter.api.Assertions.assertTrue;


@ExtendWith(MockitoExtension.class)
public class GassMessageProcessorTest {

    private final String[] xmlLabels = {
            "dataAudit",
            "borrowerList",
            "borrower",
            "customerCode",
            "customerType",
            "name",
            "originAccount",
            "destinationAccount",
            "multiChannelContractId",
            "earlyRepaymentChargeIndicator",
            "earlyRepaymentChargeAmount",
            "overpaymentAmount",
            "totalPaymentAmount",
            "loanDetails",
            "loan",
            "loanSchema",
            "loanApplicationSequenceNumber",
            "optionChosen",
            "loanErcAmount",
            "loanOverpaymentAmount",
            "loanTotalPaymentAmount",
            "newMonthlyPayment",
            "newLoanEndDate",
            "interestSaving",
    };
    GassMessageProcessor messageProcessor;

    @BeforeEach
    void setUp() {
        messageProcessor = new GassMessageProcessor();
    }


    @Test
    public void setUpInternalTransferFormattedDataToXmlString_OK() throws Exception {
        boolean everythingInPlace = true;
        String message = messageProcessor.setUpInternalTransferFormattedDataToXmlString(genericSetUpInternalTransferFormattedData());
        for (String xmlLabel : xmlLabels) {
            if (!message.contains(xmlLabel)) {
                System.out.println(xmlLabel + " is not in place");
                everythingInPlace = false;
            }
        }
        assertTrue(everythingInPlace);
    }

    @Test
    public void makeInternalTransferFormattedDataToXmlString_OK() throws Exception {
        boolean everythingInPlace = true;
        String message = messageProcessor.makeInternalTransferFormattedDataToXmlString(genericMakeInternalTransferFormattedData());
        for (String xmlLabel : xmlLabels) {
            if (!message.contains(xmlLabel)) {
                System.out.println(xmlLabel + " is not in place");
                everythingInPlace = false;
            }
        }
        assertTrue(everythingInPlace);
    }

}
