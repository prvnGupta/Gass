package com.santanderuk.corinthian.hub.corinthiangass;

import com.santanderuk.corinthian.hub.corinthiangass.common.Borrower;
import com.santanderuk.corinthian.hub.corinthiangass.common.BorrowerElement;
import com.santanderuk.corinthian.hub.corinthiangass.common.Loan;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassLoanDetails;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;

import java.util.ArrayList;
import java.util.List;


public class GassBaseTest {

    ///////////////////////////////////////////////////////
    ///  UTILITIES                                      ///
    ///////////////////////////////////////////////////////
    public static SetUpInternalTransferFormattedData genericSetUpInternalTransferFormattedData() {
        SetUpInternalTransferFormattedData formattedData = new SetUpInternalTransferFormattedData();
        BorrowerElement borrowerElement = new BorrowerElement("Borrower Name", "Borrower Type", "Customer Code");
        List<BorrowerElement> borrowerList = new ArrayList<BorrowerElement>();
        borrowerList.add(borrowerElement);
        Borrower borrower = new Borrower(borrowerList);
        formattedData.setBorrowerList(borrower);
        formattedData.setOriginAccount("origin account");
        formattedData.setDestinationAccount("destination account");
        formattedData.setMultiChannelContractId("001500755201234567");
        formattedData.setEarlyRepaymentChargeIndicator("erc indicator");
        formattedData.setEarlyRepaymentChargeAmount("erc amount");
        formattedData.setOverpaymentAmount("ovp amount");
        formattedData.setTotalPaymentAmount("total payment amount");
        Loan loanElement = new Loan("3T", 1, "M", "2.12", "7.88", "10.00", "312.00", "3 years, 10 months", "145.78");
        Loan loanElement2 = new Loan("3R", 2, "T", "2.12", "7.88", "10.00", "312.00", "3 years, 10 months", "145.78");
        List<Loan> loans = new ArrayList<Loan>();
        loans.add(loanElement);
        loans.add(loanElement2);
        GassLoanDetails loanDetails = new GassLoanDetails(loans);
        formattedData.setLoanDetails(loanDetails);

        return formattedData;
    }

    public static MakeInternalTransferFormattedData genericMakeInternalTransferFormattedData() {
        MakeInternalTransferFormattedData formattedData = new MakeInternalTransferFormattedData();
        BorrowerElement borrowerElement = new BorrowerElement("Borrower Name", "Borrower Type", "Customer Code");
        List<BorrowerElement> borrowerList = new ArrayList<BorrowerElement>();
        borrowerList.add(borrowerElement);
        Borrower borrower = new Borrower(borrowerList);
        formattedData.setBorrowerList(borrower);
        formattedData.setOriginAccount("origin account");
        formattedData.setDestinationAccount("destination account");
        formattedData.setMultiChannelContractId("001500755201234567");
        formattedData.setEarlyRepaymentChargeIndicator("erc indicator");
        formattedData.setEarlyRepaymentChargeAmount("erc amount");
        formattedData.setOverpaymentAmount("ovp amount");
        formattedData.setTotalPaymentAmount("total payment amount");
        Loan loanElement = new Loan("Loan Schema", 1, "Option Chosen", "Erc Amount", "Overpayment Amount", "Total Payment Amount", "New Monthly Amount", "Mortgage Term", "Interest Saving");
        List<Loan> loans = new ArrayList<Loan>();
        loans.add(loanElement);
        GassLoanDetails loanDetails = new GassLoanDetails(loans);
        formattedData.setLoanDetails(loanDetails);

        return formattedData;
    }

    public static MakeInternalTransferGassItem genericMakeInternalTransferGassItem() {
        MakeInternalTransferGassItem makeInternalTransferGassItem = new MakeInternalTransferGassItem(
                "gassMqHost",                                                                   // gassMqHost
                "gassMqVirtualHost",                                                            // gassMqVirtualHost
                80,                                                                             // gassMqPort
                "gassMqQueue",                                                                  // gassMqQueue
                "gassMqUsername",                                                               // gassMqUsername
                "gassMqPassword",                                                               // gassMqPassword
                "9999",                                                                         // compsysid
                "9999",                                                                         // dvctyp
                "9999",                                                                         // orgid
                "9999",                                                                         // arguttp
                "authcduserid",                                                                 // authcduserid
                "9999",                                                                         // authcdcompsysid
                "9999",                                                                         // appsysid
                "9999",                                                                         // audittrngrpid
                "trntpname",                                                                    // trntpname
                "11",                                                                           // oprtnsuctyp
                "custNumber",                                                                   // custNumber
                "account",                                                                      // account
                "3.13",                                                                       // amount
                "clientIpAddress",                                                              // clientIpAddress
                "userId",                                                                       // userId
                genericMakeInternalTransferFormattedData()            // formattedData
        );
        makeInternalTransferGassItem.setStringAuditRecord("");
        return makeInternalTransferGassItem;
    }

    public static SetUpInternalTransferGassItem genericSetUpInternalTransferGassItem() {
        SetUpInternalTransferGassItem setUpInternalTransferGassItem = new SetUpInternalTransferGassItem(
                "gassMqHost",                                                                   // gassMqHost
                "gassMqVirtualHost",                                                            // gassMqVirtualHost
                80,                                                                             // gassMqPort
                "gassMqQueue",                                                                  // gassMqQueue
                "gassMqUsername",                                                               // gassMqUsername
                "gassMqPassword",                                                               // gassMqPassword
                "9999",                                                                         // compsysid
                "9999",                                                                         // dvctyp
                "9999",                                                                         // orgid
                "9999",                                                                         // arguttp
                "authcduserid",                                                                 // authcduserid
                "9999",                                                                         // authcdcompsysid
                "9999",                                                                         // appsysid
                "9999",                                                                         // audittrngrpid
                "trntpname",                                                                    // trntpname
                "11",                                                                           // oprtnsuctyp
                "custNumber",                                                                   // custNumber
                "account",                                                                      // account
                "3.14",                                                                       // amount
                "clientIpAddress",                                                              // clientIpAddress
                "userId",                                                                       // userId
                genericSetUpInternalTransferFormattedData()            // formattedData
        );
        setUpInternalTransferGassItem.setStringAuditRecord("");
        return setUpInternalTransferGassItem;
    }
}
